<?php
session_start();
require_once('connection.php');

function register($connection, $post)
{
	if(filter_var($post['email'], FILTER_VALIDATE_EMAIL))
	{ 
		$_SESSION['message'] = 'The email address you entered, '. $post['email'].' is a valid email address! Thank you!';
		$query = "INSERT INTO users (email, created_at, updated_at) VALUES('".$post['email']."', NOW(), NOW())";
		// echo $query;
		mysqli_query($connection, $query);
		if(isset($_SESSION['message']))
		{
			$query = "SELECT email, created_at FROM users";
			$result = mysqli_query($connection, $query);
			$row = mysqli_fetch_assoc($result);
			// $_SESSION['row'] = $row;
		}
		header('Location: success.php');
		exit;
		}
		else
		{
		$_SESSION['message'] = 'The email address you entered, '. $_POST['email'].' is not a valid email address!';
		header('Location: basic_3.php');
		exit;
		}
}

if(isset($_POST['action']) && $_POST['action'] == 'validate')
{	
register($connection, $_POST);
}
?>