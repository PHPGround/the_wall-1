<?php
session_start();
require_once('connection.php'); 
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Success</title>
</head>
<body>
<?php
if(isset($_SESSION['message']))
{
	echo '<p style="background: green; 
			border 1px solid black;
			width: 300px;
			margin: 0 auto;
			">'.$_SESSION['message']. '</p>';
?>
<!-- <form action="process.php" method="post">
	<input type="hidden" name="action" value="reset">
	<input type="submit" value="Reset">
</form> -->
<?php			
	$query = "SELECT email, created_at FROM users";
	$result = mysqli_query($connection, $query);		
	while($row = mysqli_fetch_assoc($result))
	{
		echo '<h2>'.$row['email']. '   '.date('d/m/y, g:i A', strtotime($row['created_at'])).'</h2>';
	}
}

?>
</body>
</html>