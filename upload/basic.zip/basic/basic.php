<?php
session_start();
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Basic III</title>
	<style>
		.content{
			width: 300px;
			margin: 0 auto;
		}
	</style>
</head>
<body>
	<div class="content">
	<?php
		if(isset($_SESSION['message']))
		{
			echo '<p style="background: red; 
					border 1px solid black;
					width: 300px;
					margin: 0 auto;
					">'.$_SESSION['message']. '</p>';
		}
	?>
	<form action="process.php" method="post">
		<input type="hidden" name="action" value="validate">
		<label>Enter Your Email Address Here: </label><br>
		<input type="text" name="email" placeholder="Enter Email"><br>
		<input type="submit" name="submit" value="Submit">
	</form>
	</div>
</body>
</html>

<?php
	$_SESSION = array();
?>